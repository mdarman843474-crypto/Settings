# PIN Settings

Original Settings jaisi list. Har row asli Android Settings page kholti hai, isliye wahan ke saare toggle asli kaam karte hain.

## Do alag lock, do alag PIN
**1. App lock (4 digit PIN)**
- "App lock" switch ON karo: 4 digit PIN do baar dalo. Phir app kholne par ye PIN maangti hai (number pad, 4 dots, 4th digit par apne aap check).
- Band karne ke liye pehle 4 digit PIN dalna padta hai. PIN badalna ho to lock OFF karo, phir ON karke naya PIN banao.
- Upar "Lock" button se app turant lock ho jati hai. 1 minute bahar rehne par bhi lock ho jati hai.

**2. Original Settings lock (12 digit PIN)**
- "Original Settings lock" ON karte waqt 12 digit PIN banta hai (pehli baar).
- Ye PIN in kaamon ke liye chahiye: lock hatana, "Settings PIN badlo", "Device owner hatao".
- Rows (Wi-Fi, Bluetooth wagairah) kholne ke liye ye PIN nahi chahiye.
- App lock aur Settings lock ke PIN alag hain, ek dusre se judte nahi.

Purane version ka PIN apne aap sahi jagah chala jata hai: 4 digit wala App PIN ban jata hai (App lock ON), 12 digit wala Settings PIN ban jata hai.

## Rows (Settings jaisi poori list)
- System apps updater, Security status
- Wi-Fi, Bluetooth, Mobile networks, Portable hotspot
- Lock screen, Notifications & status bar, Home screen, Display & brightness, Sound & vibration, Personalisation
- Fingerprints / face data / screen lock, Safety and emergency, Privacy protection, Apps, Battery
- Digital Wellbeing & parental controls
- Google
- Privacy, Location, Feedback
- App lock (4 digit PIN) aur Original Settings (12 digit PIN) ke options
- Jaanch: "Pages check"

About phone, More connectivity options aur Additional settings isme nahi hain.

## Rows kaise khulti hain
Har row apne page ko kai tareeke se dhoondti hai: Android ke standard intents, Xiaomi/Google ke known pages, Settings ke tiles aur Settings ke andar ke activities. Jo pehla is phone par khule wahi khulta hai.
"Pages check" dabane par har row ke liye dikhta hai ki kaunsa page mila (OK) ya nahi mila (X). "Copy" dabake mujhe bhej do, main nahi milne wali rows theek kar dunga.
Row ka page na mile aur Original Settings lock OFF ho to main Settings khulti hai (message ke saath). Lock ON ho to poori Settings nahi khulti, message aata hai.

## Home se App info
- Original Settings lock ON ho to Home screen par app long-press karke "App info" ab bhi khulta hai.
- Kaise: "Home se App info" switch ON ho (shuru me ON). App info ka intent is app se gujarta hai, Settings kuch der ke liye khulti hai, Home / Recents band rehte hain, aur Back dabate hi Settings dobara lock.
- Is app ka apna App info band rakha gaya hai.
- "App info lock" switch ON karo to App info khulne par bhi uninstall, force stop, clear data aur disable band rehte hain (original Settings me bhi). Ye switch shuru me OFF hai.
- Ye tabhi chalta hai jab Home ka launcher App info ko standard intent se kholta ho. Na khule to "Pages check" ka result bhej do.

## APK banana
**GitHub se (PC ke bina)**
1. Is folder ki saari files ek naye GitHub repo me upload karo.
2. `.github/workflows/build.yml` honi chahiye. Na ho to `BUILD_WORKFLOW.yml` ka content us path par paste karo.
3. Actions tab me "Build APK" chalao (Run workflow).
4. Khatam hone par Artifacts me `PinSettings-apk` download karo. Zip kholkar `app-debug.apk` install karo.

**Android Studio se:** project kholo, Build, Build APK(s).

## Device owner (ek baar, Settings lock ke liye)
1. Ek phone par ek hi device owner ho sakta hai. PIN DNS Lock jaisi koi aur app device owner hai to pehle usse hatao.
2. Phone se Google / Mi account kuch der ke liye hatao.
3. APK install karo aur app kholo.
4. PC ya dusre phone se chalao:
   `adb shell dpm set-device-owner com.pinsettings.app/.AdminReceiver`
5. App me "Device owner" Active dikhna chahiye. Phir "Original Settings lock" ON karo.

Xiaomi par `MANAGE_DEVICE_ADMINS` wala error aaye to Developer options me "USB debugging (Security settings)" ON karo.

## Original Settings lock kaise kaam karta hai
- Lock ON: phone ki asli Settings band (pehle suspend, na ho to hide).
- Sirf ye rows khulti hain. Row dabane par Settings khulti hai aur Home / Recents / notification shade band ho jate hain.
- Back dabake app me wapas aate hi Home wapas aa jata hai aur Settings turant dobara lock ho jati hai.
- Power menu khula rehta hai. Restart karne par bhi Settings dobara lock ho jati hai.
- "Max session time" sirf safety timer hai: itni der baad Settings apne aap band.
- Row ka page phone par nahi khulta to poori Settings nahi khulti, message aata hai. Wo row ka naam bhej do.
- Baaki Settings chahiye to lock OFF karo (12 digit PIN), kaam karo, phir ON karo.
- Phone ke apne App lock se Settings lock mat karo. Wo lock koi app bypass nahi kar sakti.
- Lock ON na ho paye ya Home band na ho to app message dikhati hai. Wo bhej do.
- App hi na khule aur Settings hide hui ho to: `adb shell pm unhide com.android.settings`

## Dhyan rakho
- Device owner banne ke baad app uninstall nahi hoti. Hatane ke liye app me "Device owner hatao" (12 digit PIN chahiye).
- 12 digit PIN bhool gaye to device owner hat nahi sakta. Sirf phone factory reset (Recovery) se hatega. PIN yaad rakho.
- 5 galat PIN ke baad kuch der wait karna padta hai.
- Wi-Fi, Bluetooth, hotspot ke toggle Android third-party app ko khud karne nahi deta. Isliye app asli Settings page kholti hai.
- Settings page ke andar ke related pages khul sakte hain (jaise Wi-Fi ke andar ke options). Home aur Recents band rehte hain.
