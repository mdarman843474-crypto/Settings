package com.pinsettings.app

import android.app.Activity
import android.content.ComponentName
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast

/**
 * App info ka intent yahan aata hai (AppInfoProxy ki wajah se).
 * Settings kuch der ke liye kholkar asli App info page dikhati hai, wapas aate hi Settings dobara lock.
 */
class AppInfoActivity : Activity() {

    private var forwarded = false
    private var ownsSession = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val data = intent.data
        val pkg = data?.schemeSpecificPart
        if (data == null || pkg == null) {
            finish()
            return
        }
        if (pkg == packageName) {
            toast("Is app ka App info band hai")
            finish()
            return
        }
        // Pehle se session khula ho to usse mat chhedo
        ownsSession = !SettingsGuard.isSessionOpen(this)
        if (!SettingsGuard.prepare(this)) {
            toast("Original Settings unlock nahi ho payi")
            finish()
            return
        }
        if (forward(data)) {
            forwarded = true
            // Settings lock ON nahi hai to kaam yahin khatam
            if (!SettingsGuard.isEnabled(this)) finish()
        } else {
            if (ownsSession) SettingsGuard.endSession(this, true)
            toast("App info nahi khul saka")
            finish()
        }
    }

    /** App info page se wapas aane par: Home wapas, Settings dobara lock. */
    override fun onRestart() {
        super.onRestart()
        if (forwarded) {
            if (ownsSession) SettingsGuard.endSession(this, true)
            finish()
        }
    }

    /** Asli App info page ko seedha (explicit) kholta hai, taaki wapas yahin na aaye. */
    private fun forward(data: Uri): Boolean {
        val base = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, data)
        base.addCategory(Intent.CATEGORY_DEFAULT)
        val targets = ArrayList<ComponentName>()
        try {
            val list = packageManager.queryIntentActivities(base, PackageManager.MATCH_DEFAULT_ONLY)
            for (ri in list) {
                val ai = ri.activityInfo ?: continue
                if (ai.packageName != packageName && ai.exported) {
                    targets.add(ComponentName(ai.packageName, ai.name))
                }
            }
        } catch (e: Exception) {
            // neeche wali known list try hogi
        }
        targets.add(ComponentName("com.android.settings", "com.android.settings.applications.InstalledAppDetailsTop"))
        targets.add(ComponentName("com.android.settings", "com.android.settings.applications.InstalledAppDetails"))
        for (t in targets) {
            try {
                val i = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, data)
                i.component = t
                val ex = intent.extras
                if (ex != null) i.putExtras(ex)
                startActivity(i)
                return true
            } catch (e: Exception) {
                // agla try karo
            }
        }
        return false
    }

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }
}
