package com.pinsettings.app

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.os.UserManager

/** Device owner status, App info lock aur device owner hatana. */
object Policy {

    /** "App info lock": uninstall, force stop, clear data, disable band (UserManager.DISALLOW_APPS_CONTROL). */
    const val APPS_CONTROL = "no_control_apps"

    private fun dpm(c: Context): DevicePolicyManager =
        c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

    private fun admin(c: Context) = ComponentName(c, AdminReceiver::class.java)

    fun isOwner(c: Context): Boolean =
        try {
            dpm(c).isDeviceOwnerApp(c.packageName)
        } catch (e: Exception) {
            false
        }

    fun hasRestriction(c: Context, key: String): Boolean =
        try {
            (c.getSystemService(Context.USER_SERVICE) as UserManager).hasUserRestriction(key)
        } catch (e: Exception) {
            false
        }

    fun setRestriction(c: Context, key: String, on: Boolean): Boolean =
        try {
            if (on) {
                dpm(c).addUserRestriction(admin(c), key)
            } else {
                dpm(c).clearUserRestriction(admin(c), key)
            }
            true
        } catch (e: Exception) {
            false
        }

    /** Saare lock hatakar device owner hata deta hai. */
    fun release(c: Context): Boolean =
        try {
            SettingsGuard.disable(c)
            setRestriction(c, APPS_CONTROL, false)
            dpm(c).clearDeviceOwnerApp(c.packageName)
            try {
                dpm(c).removeActiveAdmin(admin(c))
            } catch (e: Exception) {
                // koi baat nahi
            }
            true
        } catch (e: Exception) {
            false
        }
}
