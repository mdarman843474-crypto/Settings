package com.pinsettings.app

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings

/**
 * Home screen par app long-press karke "App info" kholne par, Settings lock hone ke bawajood App info khule.
 *
 * Device owner ek "persistent preferred activity" lagata hai: App info ka intent AppInfoActivity ke paas jata hai.
 * Wo Settings ko kuch der ke liye kholkar asli App info page dikhati hai aur wapas aate hi lock kar deti hai.
 */
object AppInfoProxy {

    private fun prefs(c: Context) = c.getSharedPreferences("appinfo", Context.MODE_PRIVATE)

    private fun dpm(c: Context): DevicePolicyManager =
        c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager

    private fun admin(c: Context) = ComponentName(c, AdminReceiver::class.java)

    private fun proxy(c: Context) = ComponentName(c, AppInfoActivity::class.java)

    /** User ka switch (shuru me ON). Asli kaam tabhi hota hai jab Settings lock bhi ON ho. */
    fun isEnabled(c: Context): Boolean = prefs(c).getBoolean("enabled", true)

    fun setEnabled(c: Context, on: Boolean) {
        prefs(c).edit().putBoolean("enabled", on).apply()
        sync(c)
    }

    /** Device owner + Settings lock ON + switch ON ho to proxy lagao, warna hata do. */
    fun sync(c: Context) {
        if (Policy.isOwner(c) && SettingsGuard.isEnabled(c) && isEnabled(c)) {
            register(c)
        } else {
            clear(c)
        }
    }

    private fun register(c: Context) {
        try {
            c.packageManager.setComponentEnabledSetting(
                proxy(c), PackageManager.COMPONENT_ENABLED_STATE_ENABLED, PackageManager.DONT_KILL_APP
            )
            val d = dpm(c)
            d.clearPackagePersistentPreferredActivities(admin(c), c.packageName)
            val f = IntentFilter(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
            f.addCategory(Intent.CATEGORY_DEFAULT)
            f.addDataScheme("package")
            d.addPersistentPreferredActivity(admin(c), f, proxy(c))
        } catch (e: Exception) {
            // koi baat nahi, App info normal chalega
        }
    }

    fun clear(c: Context) {
        try {
            if (Policy.isOwner(c)) {
                dpm(c).clearPackagePersistentPreferredActivities(admin(c), c.packageName)
            }
        } catch (e: Exception) {
            // koi baat nahi
        }
        try {
            c.packageManager.setComponentEnabledSetting(
                proxy(c), PackageManager.COMPONENT_ENABLED_STATE_DISABLED, PackageManager.DONT_KILL_APP
            )
        } catch (e: Exception) {
            // koi baat nahi
        }
    }

    /** Jaanch ke liye: abhi App info ka page kaun kholta hai aur proxy ON hai ya nahi. */
    fun report(c: Context): String {
        val sb = StringBuilder()
        val on = Policy.isOwner(c) && SettingsGuard.isEnabled(c) && isEnabled(c)
        sb.append("App info proxy: ").append(if (on) "ON" else "OFF").append("\n")
        try {
            val i = Intent(
                Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.fromParts("package", c.packageName, null)
            )
            i.addCategory(Intent.CATEGORY_DEFAULT)
            val list = c.packageManager.queryIntentActivities(i, PackageManager.MATCH_DEFAULT_ONLY)
            if (list.isEmpty()) sb.append("App info page: koi nahi mila\n")
            for (ri in list) {
                val ai = ri.activityInfo ?: continue
                sb.append("App info page: ").append(ai.packageName).append("/").append(ai.name)
                    .append(" (priority ").append(ri.priority).append(")\n")
            }
        } catch (e: Exception) {
            sb.append("App info jaanch fail: ").append(e.javaClass.simpleName).append("\n")
        }
        return sb.toString()
    }
}
