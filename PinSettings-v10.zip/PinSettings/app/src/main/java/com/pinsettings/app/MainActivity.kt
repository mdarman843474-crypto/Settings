package com.pinsettings.app

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.wifi.WifiManager
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        private const val OWNER_CMD =
            "adb shell dpm set-device-owner com.pinsettings.app/.AdminReceiver"
        private var unlocked = false
        private var leftAt = 0L
    }

    private val bg = Color.BLACK
    private val cardColor = Color.parseColor("#242424")
    private val white = Color.WHITE
    private val gray = Color.parseColor("#8E8E93")
    private val blue = Color.parseColor("#2F80ED")
    private val green = Color.parseColor("#1FBF5B")
    private val purple = Color.parseColor("#8B7CF6")
    private val orange = Color.parseColor("#F2531D")
    private val teal = Color.parseColor("#0FA5A0")
    private val red = Color.parseColor("#E5484D")
    private val slate = Color.parseColor("#5B5B66")
    private val indigo = Color.parseColor("#6D6BF5")

    private val wrap = ViewGroup.LayoutParams.WRAP_CONTENT
    private val match = ViewGroup.LayoutParams.MATCH_PARENT

    private var scroll: ScrollView? = null
    private var padCancel: (() -> Unit)? = null

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        PinStore.migrate(this)
        route()
    }

    override fun onStart() {
        super.onStart()
        // Settings se wapas aate hi: Home wapas + Settings dobara lock
        SettingsGuard.endSession(this)
        if (!appLockOn()) {
            if (scroll != null) refresh()
            return
        }
        if (!unlocked) return
        if (leftAt != 0L && SystemClock.elapsedRealtime() - leftAt > 60_000L) {
            // 1 minute se zyada bahar rahe: dobara App PIN
            unlocked = false
            route()
        } else if (scroll != null) {
            refresh()
        }
    }

    override fun onStop() {
        super.onStop()
        leftAt = SystemClock.elapsedRealtime()
    }

    override fun onBackPressed() {
        val c = padCancel
        if (c != null) {
            c()
        } else {
            super.onBackPressed()
        }
    }

    private fun route() {
        if (appLockOn() && !unlocked) showEntry() else showHome()
    }

    private fun refresh() {
        val y = scroll?.scrollY ?: 0
        showHome()
        scroll?.post { scroll?.scrollTo(0, y) }
    }

    // ---------------------------------------------------------------- App lock (4 digit)

    private fun appLockOn(): Boolean =
        getSharedPreferences("app", Context.MODE_PRIVATE).getBoolean("app_lock", false) &&
            PinStore.isSet(this, PinStore.APP)

    private fun setAppLock(on: Boolean) {
        getSharedPreferences("app", Context.MODE_PRIVATE).edit().putBoolean("app_lock", on).apply()
    }

    private fun showEntry() {
        showPad("PIN dalo", "App kholne ke liye 4 digit PIN", "", PinStore.len(PinStore.APP), null) { pin ->
            val err = pinError(PinStore.APP, pin)
            if (err == null) {
                unlocked = true
                showHome()
            }
            err
        }
    }

    private fun onAppLockSwitch(on: Boolean) {
        if (on) {
            setupPin(PinStore.APP, { showHome() }, {
                setAppLock(true)
                unlocked = true
                showHome()
            }, "")
        } else {
            verifyPin(PinStore.APP, "App PIN dalo", { showHome() }) {
                setAppLock(false)
                PinStore.clear(this, PinStore.APP)
                toast("App lock band")
                showHome()
            }
        }
    }

    // ---------------------------------------------------------------- Original Settings lock (12 digit)

    private fun onGuardSwitch(on: Boolean) {
        val hasPin = PinStore.isSet(this, PinStore.GUARD)
        if (on) {
            if (hasPin) {
                enableGuard()
            } else {
                setupPin(PinStore.GUARD, { showHome() }, { enableGuard() }, "")
            }
        } else {
            if (hasPin) {
                verifyPin(PinStore.GUARD, "Settings PIN dalo", { showHome() }) { disableGuard() }
            } else {
                disableGuard()
            }
        }
    }

    private fun onProxySwitch(on: Boolean) {
        AppInfoProxy.setEnabled(this, on)
        refresh()
        if (on && !SettingsGuard.isEnabled(this)) {
            toast("Ye Original Settings lock ON hone par kaam karega")
        }
    }

    private fun onAppInfoLockSwitch(on: Boolean) {
        if (!Policy.setRestriction(this, Policy.APPS_CONTROL, on)) toast("Ho nahi paya")
        refresh()
    }

    private fun enableGuard() {
        val ok = SettingsGuard.enable(this)
        refresh()
        if (ok) {
            toast("Original Settings band. Ab sirf is app ki rows se khulegi")
        } else {
            dialog()
                .setTitle("Lock nahi laga")
                .setMessage(
                    "Original Settings suspend ya hide nahi ho payi.\n\n" +
                        SettingsGuard.lastDetail + "\n\nYe message bhej do."
                )
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun disableGuard() {
        SettingsGuard.disable(this)
        refresh()
        toast("Original Settings lock hat gaya")
    }

    private fun changeGuardPin() {
        if (!PinStore.isSet(this, PinStore.GUARD)) {
            toast("Settings PIN abhi set nahi hai. Lock ON karte waqt set hoga")
            return
        }
        verifyPin(PinStore.GUARD, "Purana Settings PIN dalo", { showHome() }) {
            setupPin(PinStore.GUARD, { showHome() }, {
                toast("Settings PIN badal gaya")
                showHome()
            }, "")
        }
    }

    private fun releaseOwner() {
        if (!Policy.isOwner(this)) {
            toast("Device owner active nahi hai")
            return
        }
        if (PinStore.isSet(this, PinStore.GUARD)) {
            verifyPin(PinStore.GUARD, "Settings PIN dalo", { showHome() }) { confirmRelease() }
        } else {
            confirmRelease()
        }
    }

    private fun confirmRelease() {
        showHome()
        dialog()
            .setTitle("Device owner hatana hai?")
            .setMessage("Original Settings ka lock hat jayega aur ye app device owner nahi rahegi.")
            .setPositiveButton("Haan, hatao") { _, _ ->
                if (Policy.release(this)) {
                    toast("Device owner hat gaya")
                } else {
                    toast("Hat nahi saka")
                }
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------------------------------------------------------- PIN flows

    /** null = PIN sahi, warna dikhane wala error message. */
    private fun pinError(kind: String, pin: String): String? {
        val wait = PinStore.waitMs(this, kind)
        if (wait > 0L) return "Ruko, ${wait / 1000 + 1} second baad try karo"
        return if (PinStore.check(this, kind, pin)) null else "Galat PIN"
    }

    /** Naya PIN do baar lekar save karta hai, phir saved() bulata hai. */
    private fun setupPin(kind: String, cancel: () -> Unit, saved: () -> Unit, note: String) {
        val len = PinStore.len(kind)
        val name = if (kind == PinStore.APP) "App PIN" else "Settings PIN"
        showPad("Naya $name set karo", "$len digit ka PIN. Bhoolna mat.", note, len, cancel) { first ->
            showPad("PIN dobara dalo", "Wahi $len digit phir se dalo", "", len, cancel) { again ->
                if (again == first) {
                    PinStore.save(this, kind, again)
                    saved()
                    null
                } else {
                    setupPin(kind, cancel, saved, "Dono PIN match nahi hue")
                    null
                }
            }
            null
        }
    }

    /** PIN pooch kar sahi hone par ok() bulata hai. */
    private fun verifyPin(kind: String, title: String, cancel: () -> Unit, ok: () -> Unit) {
        val len = PinStore.len(kind)
        showPad(title, "$len digit PIN dalo", "", len, cancel) { pin ->
            val err = pinError(kind, pin)
            if (err == null) ok()
            err
        }
    }

    /**
     * Number pad screen. len digit poore hote hi onDone(pin) bulata hai.
     * onDone error message (String) return kare to dots saaf ho kar wahi dikhta hai, null ho to aage badh gaye.
     */
    private fun showPad(
        title: String,
        sub: String,
        note: String,
        len: Int,
        onCancel: (() -> Unit)?,
        onDone: (String) -> String?
    ) {
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        padCancel = onCancel
        val entered = StringBuilder()
        val dotViews = ArrayList<TextView>()

        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.gravity = Gravity.CENTER_HORIZONTAL
        box.setPadding(dp(24), dp(40), dp(24), dp(24))

        val t = label(title, 28f, white, true)
        t.gravity = Gravity.CENTER
        box.addView(t, LinearLayout.LayoutParams(match, wrap))

        val s = label(sub, 14f, gray)
        s.gravity = Gravity.CENTER
        s.setPadding(dp(8), dp(8), dp(8), dp(24))
        box.addView(s, LinearLayout.LayoutParams(match, wrap))

        val dots = LinearLayout(this)
        dots.orientation = LinearLayout.HORIZONTAL
        dots.gravity = Gravity.CENTER
        for (k in 0 until len) {
            val d = label("\u25CB", if (len > 6) 20f else 30f, white)
            d.setPadding(dp(if (len > 6) 4 else 10), 0, dp(if (len > 6) 4 else 10), 0)
            dots.addView(d)
            dotViews.add(d)
        }
        box.addView(dots, LinearLayout.LayoutParams(match, wrap))

        val msg = label(note, 14f, Color.parseColor("#FF6B6B"))
        msg.gravity = Gravity.CENTER
        msg.setPadding(0, dp(14), 0, dp(14))
        box.addView(msg, LinearLayout.LayoutParams(match, wrap))

        fun refreshDots() {
            for (k in 0 until len) {
                dotViews[k].text = if (k < entered.length) "\u25CF" else "\u25CB"
            }
        }

        fun complete(pin: String) {
            val err = onDone(pin)
            if (err != null) {
                entered.setLength(0)
                refreshDots()
                msg.text = err
            }
        }

        fun press(d: String) {
            if (entered.length >= len) return
            entered.append(d)
            refreshDots()
            msg.text = ""
            if (entered.length == len) complete(entered.toString())
        }

        fun erase() {
            if (entered.isNotEmpty()) {
                entered.setLength(entered.length - 1)
                refreshDots()
            }
        }

        val rows = arrayOf(
            arrayOf("1", "2", "3"),
            arrayOf("4", "5", "6"),
            arrayOf("7", "8", "9")
        )
        for (r in rows) {
            val line = LinearLayout(this)
            line.orientation = LinearLayout.HORIZONTAL
            line.gravity = Gravity.CENTER
            for (d in r) line.addView(padKey(d) { press(d) })
            box.addView(line, LinearLayout.LayoutParams(match, wrap))
        }
        val bottom = LinearLayout(this)
        bottom.orientation = LinearLayout.HORIZONTAL
        bottom.gravity = Gravity.CENTER
        bottom.addView(padBlank())
        bottom.addView(padKey("0") { press("0") })
        bottom.addView(padKey("\u2190") { erase() })
        box.addView(bottom, LinearLayout.LayoutParams(match, wrap))

        if (onCancel != null) {
            val c = label("Cancel", 16f, Color.parseColor("#4C9AFF"))
            c.gravity = Gravity.CENTER
            c.setPadding(dp(16), dp(12), dp(16), dp(12))
            c.setOnClickListener { onCancel() }
            box.addView(c, LinearLayout.LayoutParams(match, wrap))
        }

        val sv = ScrollView(this)
        sv.setBackgroundColor(bg)
        sv.isFillViewport = true
        sv.addView(box)
        setContentView(sv)
    }

    private fun padKey(txt: String, onClick: () -> Unit): View {
        val k = TextView(this)
        k.text = txt
        k.setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
        k.setTextColor(white)
        k.gravity = Gravity.CENTER
        val g = GradientDrawable()
        g.shape = GradientDrawable.OVAL
        g.setColor(cardColor)
        k.background = g
        k.setOnClickListener { v ->
            v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            onClick()
        }
        val lp = LinearLayout.LayoutParams(dp(76), dp(76))
        lp.setMargins(dp(12), dp(8), dp(12), dp(8))
        k.layoutParams = lp
        return k
    }

    private fun padBlank(): View {
        val v = View(this)
        val lp = LinearLayout.LayoutParams(dp(76), dp(76))
        lp.setMargins(dp(12), dp(8), dp(12), dp(8))
        v.layoutParams = lp
        return v
    }

    // ---------------------------------------------------------------- Home

    private fun showHome() {
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN)
        padCancel = null
        val owner = Policy.isOwner(this)
        val appOn = appLockOn()
        val guardOn = SettingsGuard.isEnabled(this)
        val proxyOn = AppInfoProxy.isEnabled(this)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(28), dp(16), dp(36))

        val head = LinearLayout(this)
        head.gravity = Gravity.CENTER_VERTICAL
        head.addView(label("Settings", 34f, white, true), LinearLayout.LayoutParams(0, wrap, 1f))
        if (appOn) {
            val lockBtn = label("Lock", 16f, Color.parseColor("#4C9AFF"))
            lockBtn.setPadding(dp(12), dp(8), dp(12), dp(8))
            lockBtn.setOnClickListener {
                unlocked = false
                route()
            }
            head.addView(lockBtn)
        }
        col.addView(head)
        col.addView(space(18))

        for (g in Pages.groups) {
            val rows = g.map { p -> pageRow(p) }
            col.addView(card(*rows.toTypedArray()))
            col.addView(space(14))
        }
        col.addView(space(8))

        col.addView(section("App lock (4 digit PIN)"))
        col.addView(
            card(
                switchRow(
                    R.drawable.ic_lock, purple, "App lock",
                    if (appOn) "Chalu. App kholne ke liye 4 digit PIN" else "Band. PIN ke bina khulti hai",
                    appOn, true
                ) { on -> onAppLockSwitch(on) }
            )
        )
        col.addView(space(22))

        col.addView(section("Original Settings (12 digit PIN)"))
        col.addView(
            card(
                row(R.drawable.ic_privacy, teal, "Device owner", if (owner) "Active" else "Not set") {
                    if (owner) toast("Device owner active hai") else ownerHelp()
                },
                switchRow(
                    R.drawable.ic_lock, orange, "Original Settings lock",
                    if (guardOn) "Band. Rows se khulti hai, hatane ke liye 12 digit PIN"
                    else "Off. Original Settings khuli hai",
                    guardOn, owner
                ) { on -> onGuardSwitch(on) },
                switchRow(
                    R.drawable.ic_home, indigo, "Home se App info",
                    if (proxyOn) "Chalu. Home par app long-press karke App info khulta hai"
                    else "Band. Settings lock me Home se App info nahi khulega",
                    proxyOn, owner
                ) { on -> onProxySwitch(on) },
                switchRow(
                    R.drawable.ic_apps, purple, "App info lock",
                    "Uninstall, force stop, clear data band. Original Settings me bhi",
                    Policy.hasRestriction(this, Policy.APPS_CONTROL), owner
                ) { on -> onAppInfoLockSwitch(on) },
                row(R.drawable.ic_key, slate, "Settings PIN badlo", null) { changeGuardPin() },
                row(R.drawable.ic_timer, slate, "Max session time", "${SettingsGuard.minutes(this)} min") {
                    pickMinutes()
                },
                row(R.drawable.ic_cancel, red, "Device owner hatao", null) { releaseOwner() }
            )
        )
        col.addView(space(22))

        col.addView(section("Jaanch"))
        col.addView(card(row(R.drawable.ic_check, slate, "Pages check", null) { pagesCheck() }))

        val sv = ScrollView(this)
        sv.setBackgroundColor(bg)
        sv.addView(col)
        scroll = sv
        setContentView(sv)
    }

    // ---------------------------------------------------------------- actions

    private fun pageRow(p: Page): View {
        val value = when (p.title) {
            "Wi-Fi" -> wifiState()
            "Bluetooth" -> btState()
            else -> null
        }
        return row(p.icon, p.color, p.title, value, p.glyph) { openPage(p) }
    }

    private fun openPage(p: Page) {
        // Original Settings lock ho to: Settings kholo aur Home band karo
        if (!SettingsGuard.prepare(this)) {
            toast("Original Settings unlock nahi ho payi")
            return
        }
        val locked = SettingsGuard.isEnabled(this)
        if (locked && !SettingsGuard.homeLocked) {
            toast("Home band nahi ho paya")
        }
        for (i in Pages.candidates(this, p)) {
            try {
                startActivity(i)
                return
            } catch (e: Exception) {
                // agla intent try karo
            }
        }
        if (locked) {
            // lock ON ho to poori Settings mat kholo
            SettingsGuard.endSession(this, true)
            toast(p.title + ": page nahi mila. Mujhe batao")
            return
        }
        toast(p.title + ": seedha page nahi mila, Settings khol rahi hu")
        try {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        } catch (e: Exception) {
            toast("Ye screen khul nahi saki")
        }
    }

    /** Har row ke liye dikhata hai ki is phone par kaunsa page mila (dikkat dhoondne ke liye). */
    private fun pagesCheck() {
        val sb = StringBuilder()
        for (p in Pages.all()) {
            val list = Pages.candidates(this, p)
            if (list.isEmpty()) {
                sb.append("X  ").append(p.title).append(" : nahi mila\n")
            } else {
                sb.append("OK ").append(p.title).append(" : ").append(Pages.describe(list[0])).append("\n")
            }
        }
        sb.append("\n").append(AppInfoProxy.report(this))
        val text = sb.toString()
        dialog()
            .setTitle("Pages check")
            .setMessage(text)
            .setPositiveButton("OK", null)
            .setNeutralButton("Copy") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("pages", text))
                toast("Copy ho gaya")
            }
            .show()
    }

    private fun pickMinutes() {
        val opts = intArrayOf(3, 5, 10, 15, 30)
        val names = opts.map { "$it min" }.toTypedArray()
        val cur = opts.indexOf(SettingsGuard.minutes(this)).coerceAtLeast(0)
        dialog()
            .setTitle("Settings zyada se zyada kitni der khuli rahe")
            .setSingleChoiceItems(names, cur) { d, which ->
                SettingsGuard.setMinutes(this, opts[which])
                d.dismiss()
                refresh()
            }
            .show()
    }

    private fun ownerHelp() {
        dialog()
            .setTitle("Device owner set karo")
            .setMessage(
                "Ek phone par ek hi device owner ho sakta hai. PIN DNS Lock jaisi koi aur app " +
                    "device owner hai to pehle usse hatao.\n\n" +
                    "Phone par koi Google / Mi account nahi hona chahiye (baad me wapas laga sakte ho). " +
                    "PC ya dusre phone se ye command ek baar chalao:\n\n" + OWNER_CMD
            )
            .setPositiveButton("Copy command") { _, _ ->
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("cmd", OWNER_CMD))
                toast("Copy ho gaya")
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun wifiState(): String {
        return try {
            val w = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            if (w.isWifiEnabled) "On" else "Off"
        } catch (e: Exception) {
            ""
        }
    }

    private fun btState(): String {
        return try {
            when (Settings.Global.getInt(contentResolver, "bluetooth_on", -1)) {
                1 -> "On"
                0 -> "Off"
                else -> ""
            }
        } catch (e: Exception) {
            ""
        }
    }

    private fun dialog(): AlertDialog.Builder =
        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)

    // ---------------------------------------------------------------- view helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    private fun toast(s: String) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    }

    private fun label(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    private fun space(h: Int): View {
        val v = View(this)
        v.layoutParams = LinearLayout.LayoutParams(1, dp(h))
        return v
    }

    private fun section(s: String): View {
        val t = label(s, 13f, gray)
        t.setPadding(dp(12), 0, 0, dp(8))
        return t
    }

    private fun selectable(): Int {
        val v = TypedValue()
        theme.resolveAttribute(android.R.attr.selectableItemBackground, v, true)
        return v.resourceId
    }

    private fun card(vararg rows: View): View {
        val c = LinearLayout(this)
        c.orientation = LinearLayout.VERTICAL
        val g = GradientDrawable()
        g.setColor(cardColor)
        g.cornerRadius = dp(22).toFloat()
        c.background = g
        c.outlineProvider = ViewOutlineProvider.BACKGROUND
        c.clipToOutline = true
        for (r in rows) c.addView(r)
        return c
    }

    private fun tile(icon: Int, color: Int, glyph: String? = null): View {
        val f = FrameLayout(this)
        val g = GradientDrawable()
        g.setColor(if (glyph != null) Color.parseColor("#EDEDED") else color)
        g.cornerRadius = dp(11).toFloat()
        f.background = g
        if (glyph != null) {
            val tv = label(glyph, 22f, color, true)
            tv.gravity = Gravity.CENTER
            f.addView(tv, FrameLayout.LayoutParams(match, match))
        } else {
            val iv = ImageView(this)
            iv.setImageResource(icon)
            f.addView(iv, FrameLayout.LayoutParams(dp(24), dp(24), Gravity.CENTER))
        }
        f.layoutParams = LinearLayout.LayoutParams(dp(40), dp(40))
        return f
    }

    private fun row(
        icon: Int,
        color: Int,
        title: String,
        value: String?,
        glyph: String? = null,
        click: () -> Unit
    ): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(16), dp(13), dp(14), dp(13))
        r.setBackgroundResource(selectable())
        r.setOnClickListener { click() }
        r.addView(tile(icon, color, glyph))

        val lp = LinearLayout.LayoutParams(0, wrap, 1f)
        lp.leftMargin = dp(16)
        r.addView(label(title, 17f, white), lp)

        if (!value.isNullOrEmpty()) {
            val v = label(value, 15f, gray)
            v.setPadding(0, 0, dp(6), 0)
            r.addView(v)
        }
        r.addView(label("\u203A", 26f, gray))
        return r
    }

    /** onToggle khud screen badalta / refresh karta hai (PIN pad kholna ho sakta hai). */
    private fun switchRow(
        icon: Int,
        color: Int,
        title: String,
        sub: String,
        on: Boolean,
        enabled: Boolean,
        onToggle: (Boolean) -> Unit
    ): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(dp(16), dp(13), dp(14), dp(13))
        r.addView(tile(icon, color))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.addView(label(title, 17f, white))
        col.addView(label(if (enabled) sub else "Pehle device owner banao", 13f, gray))
        val lp = LinearLayout.LayoutParams(0, wrap, 1f)
        lp.leftMargin = dp(16)
        lp.rightMargin = dp(8)
        r.addView(col, lp)

        val sw = Switch(this)
        sw.isChecked = on
        sw.isEnabled = enabled
        sw.setOnCheckedChangeListener { _, v -> onToggle(v) }
        r.addView(sw)

        if (!enabled) r.alpha = 0.55f
        return r
    }
}
