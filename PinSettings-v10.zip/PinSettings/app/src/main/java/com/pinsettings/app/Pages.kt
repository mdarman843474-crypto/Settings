package com.pinsettings.app

import android.app.admin.DevicePolicyManager
import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.provider.Settings

/** Ek row: naam, icon aur wo tareeke jinse us page ko kholte hain. */
class Page(
    val title: String,
    val icon: Int,
    val color: Int,
    /** Icon ki jagah ye akshar dikhao (jaise Google ka "G"). */
    val glyph: String? = null,
    /** Seedhe intents (action ya component), pehle se aakhri tak try honge. */
    val intents: List<Intent> = emptyList(),
    /** Is app ka launch intent (app khulti hai). */
    val launchPkgs: List<String> = emptyList(),
    /** Settings ke tiles (jaise Google, Digital Wellbeing) me ye poora naam dhoondo. */
    val tileLabels: List<String> = emptyList(),
    /** Launcher apps me ye poora naam dhoondo. */
    val appLabels: List<String> = emptyList(),
    /** In packages ke exported activities ke naam me scanKeys dhoondo. */
    val scanPkgs: List<String> = emptyList(),
    val scanKeys: List<String> = emptyList()
)

object Pages {

    private const val SETTINGS = "com.android.settings"

    private val BLUE = Color.parseColor("#2F80ED")
    private val GREEN = Color.parseColor("#1FBF5B")
    private val PURPLE = Color.parseColor("#8B7CF6")
    private val ORANGE = Color.parseColor("#F2531D")
    private val AMBER = Color.parseColor("#F5A800")
    private val INDIGO = Color.parseColor("#6D6BF5")
    private val GOOGLE = Color.parseColor("#4285F4")

    private fun act(a: String) = Intent(a)

    private fun cls(pkg: String, name: String) = Intent().setClassName(pkg, name)

    /** Settings jaisi list, cards ke hisaab se. */
    val groups: List<List<Page>> = listOf(
        listOf(
            Page(
                "System apps updater", R.drawable.ic_update, ORANGE,
                launchPkgs = listOf("com.xiaomi.discover"),
                appLabels = listOf("System app updater", "System apps updater")
            ),
            Page(
                "Security status", R.drawable.ic_privacy, GREEN,
                tileLabels = listOf("Security status"),
                launchPkgs = listOf("com.miui.securitycenter")
            )
        ),
        listOf(
            Page("Wi-Fi", R.drawable.ic_wifi, BLUE, intents = listOf(act(Settings.ACTION_WIFI_SETTINGS))),
            Page(
                "Bluetooth", R.drawable.ic_bluetooth, BLUE,
                intents = listOf(act(Settings.ACTION_BLUETOOTH_SETTINGS))
            ),
            Page(
                "Mobile networks", R.drawable.ic_mobile, GREEN,
                intents = listOf(
                    act(Settings.ACTION_DATA_ROAMING_SETTINGS),
                    act(Settings.ACTION_NETWORK_OPERATOR_SETTINGS)
                ),
                scanPkgs = listOf(SETTINGS, "com.android.phone"),
                scanKeys = listOf("MobileNetwork", "SimSettings", "SimCard")
            ),
            Page(
                "Portable hotspot", R.drawable.ic_hotspot, BLUE,
                intents = listOf(
                    cls(SETTINGS, "com.android.settings.TetherSettings"),
                    cls(SETTINGS, "com.android.settings.Settings\$TetherSettingsActivity"),
                    cls(SETTINGS, "com.android.settings.Settings\$WifiApSettingsActivity")
                ),
                scanPkgs = listOf(SETTINGS),
                scanKeys = listOf("TetherSettings", "Hotspot", "WifiAp", "Tether")
            )
        ),
        listOf(
            Page(
                "Lock screen", R.drawable.ic_lock, ORANGE,
                intents = listOf(act("android.settings.LOCK_SCREEN_SETTINGS")),
                scanPkgs = listOf(SETTINGS),
                scanKeys = listOf("LockScreenSettings", "LockScreen", "Keyguard")
            ),
            Page(
                "Notifications & status bar", R.drawable.ic_notification, BLUE,
                intents = listOf(act("android.settings.NOTIFICATION_SETTINGS")),
                scanPkgs = listOf(SETTINGS),
                scanKeys = listOf(
                    "NotificationStatusBar", "StatusBar", "NotificationSettings", "ConfigureNotification"
                )
            ),
            Page(
                "Home screen", R.drawable.ic_home, INDIGO,
                scanPkgs = listOf("com.miui.home"),
                scanKeys = listOf("HomeSetting", "LauncherSetting", "Setting")
            ),
            Page(
                "Display & brightness", R.drawable.ic_brightness, AMBER,
                intents = listOf(act(Settings.ACTION_DISPLAY_SETTINGS))
            ),
            Page(
                "Sound & vibration", R.drawable.ic_sound, GREEN,
                intents = listOf(act(Settings.ACTION_SOUND_SETTINGS))
            ),
            Page(
                "Personalisation", R.drawable.ic_brush, BLUE,
                scanPkgs = listOf(SETTINGS),
                scanKeys = listOf("Personali"),
                launchPkgs = listOf("com.android.thememanager")
            )
        ),
        listOf(
            Page(
                "Fingerprints, face data, and screen lock", R.drawable.ic_fingerprint, PURPLE,
                intents = listOf(
                    act(Settings.ACTION_SECURITY_SETTINGS),
                    act(DevicePolicyManager.ACTION_SET_NEW_PASSWORD)
                )
            ),
            Page(
                "Safety and emergency", R.drawable.ic_safety, ORANGE,
                intents = listOf(act("android.intent.action.SAFETY_CENTER")),
                scanPkgs = listOf(SETTINGS, "com.android.emergency"),
                scanKeys = listOf("SafetyAndEmergency", "Emergency", "Safety"),
                launchPkgs = listOf("com.android.emergency")
            ),
            Page(
                "Privacy protection", R.drawable.ic_privacy, BLUE,
                tileLabels = listOf("Privacy protection"),
                scanPkgs = listOf("com.miui.securitycenter"),
                scanKeys = listOf("PrivacyProtect", "Privacy")
            ),
            Page(
                "Apps", R.drawable.ic_apps, BLUE,
                intents = listOf(
                    act(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS),
                    act(Settings.ACTION_APPLICATION_SETTINGS)
                )
            ),
            Page(
                "Battery", R.drawable.ic_battery, AMBER,
                intents = listOf(
                    act(Intent.ACTION_POWER_USAGE_SUMMARY),
                    act(Settings.ACTION_BATTERY_SAVER_SETTINGS)
                )
            )
        ),
        listOf(
            Page(
                "Digital Wellbeing & parental controls", R.drawable.ic_wellbeing, AMBER,
                intents = listOf(
                    cls(
                        "com.google.android.apps.wellbeing",
                        "com.google.android.apps.wellbeing.settings.TopLevelSettingsActivity"
                    )
                ),
                tileLabels = listOf("Digital Wellbeing & parental controls", "Digital Wellbeing"),
                launchPkgs = listOf("com.google.android.apps.wellbeing")
            )
        ),
        listOf(
            Page(
                "Google", 0, GOOGLE,
                glyph = "G",
                intents = listOf(
                    cls("com.google.android.gms", "com.google.android.gms.app.settings.GoogleSettingsActivity")
                ),
                tileLabels = listOf("Google")
            )
        ),
        listOf(
            Page(
                "Privacy", R.drawable.ic_eye, BLUE,
                intents = listOf(act(Settings.ACTION_PRIVACY_SETTINGS))
            ),
            Page(
                "Location", R.drawable.ic_location, AMBER,
                intents = listOf(act(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
            ),
            Page(
                "Feedback", R.drawable.ic_feedback, BLUE,
                launchPkgs = listOf("com.miui.bugreport"),
                appLabels = listOf("Feedback")
            )
        )
    )

    fun all(): List<Page> = groups.flatten()

    /** Intent ka chhota naam (jaanch ke liye). */
    fun describe(i: Intent): String {
        val comp = i.component
        if (comp != null) return comp.flattenToShortString()
        return i.action ?: i.toString()
    }

    /** Is page ko kholne wale intents, behtar pehle. Sirf wahi jo is phone par launch ho sakte hain. */
    fun candidates(c: Context, p: Page): List<Intent> {
        val raw = ArrayList<Intent>()
        raw.addAll(p.intents)
        if (p.scanKeys.isNotEmpty()) raw.addAll(scan(c, p.scanPkgs, p.scanKeys))
        if (p.tileLabels.isNotEmpty()) raw.addAll(tilesByLabel(c, p.tileLabels))
        for (pkg in p.launchPkgs) {
            val li = try {
                c.packageManager.getLaunchIntentForPackage(pkg)
            } catch (e: Exception) {
                null
            }
            if (li != null) raw.add(li)
        }
        if (p.appLabels.isNotEmpty()) raw.addAll(appsByLabel(c, p.appLabels))

        val seen = HashSet<String>()
        val out = ArrayList<Intent>()
        for (i in raw) {
            if (!launchable(c, i)) continue
            if (seen.add(describe(i))) out.add(i)
        }
        return out
    }

    private fun launchable(c: Context, i: Intent): Boolean {
        return try {
            val ri = c.packageManager.resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY)
            val ai = ri?.activityInfo
            ai != null && ai.exported && ai.enabled && ai.permission == null
        } catch (e: Exception) {
            false
        }
    }

    /** Settings ke homepage tiles (Google jaise) ko naam se dhoondta hai. */
    private fun tilesByLabel(c: Context, labels: List<String>): List<Intent> {
        val pm = c.packageManager
        val out = ArrayList<Intent>()
        val actions = listOf(
            "com.android.settings.action.IA_SETTINGS",
            "com.android.settings.action.EXTRA_SETTINGS",
            "com.android.settings.action.SETTINGS"
        )
        for (a in actions) {
            val list: List<ResolveInfo> = try {
                pm.queryIntentActivities(Intent(a), PackageManager.GET_META_DATA)
            } catch (e: Exception) {
                emptyList()
            }
            for (ri in list) {
                val ai = ri.activityInfo ?: continue
                val name = ri.loadLabel(pm).toString()
                if (labels.any { it.equals(name, ignoreCase = true) }) {
                    out.add(Intent().setClassName(ai.packageName, ai.name))
                }
            }
        }
        return out
    }

    /** Launcher ki apps ko naam se dhoondta hai. */
    private fun appsByLabel(c: Context, labels: List<String>): List<Intent> {
        val pm = c.packageManager
        val main = Intent(Intent.ACTION_MAIN)
        main.addCategory(Intent.CATEGORY_LAUNCHER)
        val out = ArrayList<Intent>()
        val list: List<ResolveInfo> = try {
            pm.queryIntentActivities(main, 0)
        } catch (e: Exception) {
            emptyList()
        }
        for (ri in list) {
            val ai = ri.activityInfo ?: continue
            val name = ri.loadLabel(pm).toString()
            if (labels.any { it.equals(name, ignoreCase = true) }) {
                out.add(Intent().setClassName(ai.packageName, ai.name))
            }
        }
        return out
    }

    /** Package ke exported activities me naam ke hisse se dhoondta hai (zyada se zyada 4). */
    private fun scan(c: Context, pkgs: List<String>, keys: List<String>): List<Intent> {
        val hits = ArrayList<Pair<Int, ActivityInfo>>()
        for (pkg in pkgs) {
            val acts: Array<ActivityInfo>? = try {
                c.packageManager.getPackageInfo(pkg, PackageManager.GET_ACTIVITIES).activities
            } catch (e: Exception) {
                null
            }
            if (acts == null) continue
            for (ai in acts) {
                if (!ai.exported || !ai.enabled || ai.permission != null) continue
                val nm = ai.name.lowercase()
                if (nm.contains("dialog") || nm.contains("receiver")) continue
                for (k in keys.indices) {
                    if (nm.contains(keys[k].lowercase())) {
                        hits.add(Pair(k, ai))
                        break
                    }
                }
            }
        }
        hits.sortWith(compareBy<Pair<Int, ActivityInfo>>({ it.first }, { it.second.name.length }))
        val out = ArrayList<Intent>()
        for (h in hits.take(4)) {
            out.add(Intent().setClassName(h.second.packageName, h.second.name))
        }
        return out
    }
}
